package com.jarvisai.assistant

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.jarvisai.assistant.skills.SkillRegistry
import com.jarvisai.assistant.skills.SkillResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * This service is what actually "acts inside apps": it's granted (by the user, manually,
 * in Settings > Accessibility) the ability to read on-screen content and perform clicks/typing.
 * MainActivity/ListeningService hand it a parsed JarvisCommand; it looks up the right Skill
 * and runs it on a background thread (UI node interactions are blocking calls).
 *
 * Android will NOT let this — or any — app bypass the lock screen. If the phone is locked,
 * this service has no window content to read and cannot act until the user unlocks it
 * themselves.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Jarvis accessibility service connected")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No passive listening needed; commands are executed on-demand via runCommand().
    }

    override fun onInterrupt() {}

    companion object {
        private const val TAG = "JarvisAccessibility"
        var instance: JarvisAccessibilityService? = null
            private set

        fun isReady(): Boolean = instance != null

        /**
         * Runs [command] against the matching skill on a background thread and delivers the
         * result on the main thread via [onResult]. This never touches the lock screen.
         */
        fun runCommand(command: JarvisCommand, onResult: (SkillResult) -> Unit) {
            val service = instance
            if (service == null) {
                onResult(SkillResult.Failed("Accessibility service isn't turned on yet."))
                return
            }
            val skill = SkillRegistry.resolve(command)
            if (skill == null) {
                onResult(SkillResult.Failed("I don't have a skill for \"${command.app}\" yet."))
                return
            }
            CoroutineScope(Dispatchers.Default).launch {
                val result = try {
                    skill.execute(service, command)
                } catch (e: Exception) {
                    SkillResult.Failed("Error running ${command.app} skill: ${e.message}")
                }
                CoroutineScope(Dispatchers.Main).launch { onResult(result) }
            }
        }
    }
}
