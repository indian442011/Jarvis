package com.jarvisai.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** A command Jarvis can execute, extracted from free-form speech. */
data class JarvisCommand(
    val app: String,       // "whatsapp", "youtube", "settings", "unknown", ...
    val action: String,    // "send_message", "open", "search", "unlock", ...
    val target: String?,   // e.g. contact name "mom"
    val text: String?,     // e.g. message body "hi"
    val reply: String      // short spoken confirmation for Jarvis to say back
)

/**
 * Uses Groq's free-tier chat completion endpoint (OpenAI-compatible) as the NLU layer,
 * so commands like "take me to YouTube" or "tell mom hi on whatsapp" resolve to a
 * structured JarvisCommand instead of relying on hand-written keyword rules.
 *
 * Model: openai/gpt-oss-20b — one of Groq's free-tier hosted models (not a Llama checkpoint),
 * chosen for low latency on short intent-extraction prompts like these. Swap the string below
 * for any other model on https://console.groq.com/docs/models if you want higher quality at
 * the cost of some speed (e.g. "openai/gpt-oss-120b").
 */
class GroqClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val systemPrompt = """
        You convert a spoken command (which may use slang or be phrased loosely) into JSON only,
        no prose, no markdown fences. Schema:
        {"app": string, "action": string, "target": string|null, "text": string|null, "reply": string}
        - "app": the target app in lowercase (e.g. "whatsapp", "youtube", "phone_lock_screen", "unknown")
        - "action": one of "open", "send_message", "search", "call", "unlock", "unknown"
        - "target": a contact/channel/search subject if any, else null
        - "text": message body to send if any, else null
        - "reply": a short first-person sentence Jarvis should speak back to the user
        Examples:
        "take me to youtube" -> {"app":"youtube","action":"open","target":null,"text":null,"reply":"Opening YouTube."}
        "send hi to mom on whatsapp" -> {"app":"whatsapp","action":"send_message","target":"mom","text":"hi","reply":"Sending hi to mom on WhatsApp."}
    """.trimIndent()

    fun parseCommand(heardText: String): Result<JarvisCommand> = try {
        val body = JSONObject().apply {
            put("model", "openai/gpt-oss-20b")
            put("temperature", 0.1)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt))
                put(JSONObject().put("role", "user").put("content", heardText))
            })
        }

        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) {
                return Result.failure(Exception("Groq error ${resp.code}: ${resp.body?.string()}"))
            }
            val json = JSONObject(resp.body?.string() ?: "{}")
            val content = json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim()
                .removePrefix("```json").removePrefix("```").removeSuffix("```")
                .trim()

            val parsed = JSONObject(content)
            Result.success(
                JarvisCommand(
                    app = parsed.optString("app", "unknown"),
                    action = parsed.optString("action", "unknown"),
                    target = parsed.optString("target", null).takeIf { it != "null" },
                    text = parsed.optString("text", null).takeIf { it != "null" },
                    reply = parsed.optString("reply", "Okay.")
                )
            )
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}
