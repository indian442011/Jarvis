package com.jarvisai.assistant.skills

import com.jarvisai.assistant.JarvisCommand

/**
 * Add a new Skill implementation here to teach Jarvis another app.
 * Order matters: more specific skills should be listed before the generic launcher fallback.
 */
object SkillRegistry {

    private val skills: List<Skill> = listOf(
        WhatsAppSkill(),
        YouTubeSkill(),
        AppLauncherSkill() // fallback: generic "open <app>" for anything without a dedicated skill
    )

    fun resolve(command: JarvisCommand): Skill? = skills.firstOrNull { it.canHandle(command) }
}
