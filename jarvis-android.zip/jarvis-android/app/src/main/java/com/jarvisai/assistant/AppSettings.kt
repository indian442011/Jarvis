package com.jarvisai.assistant

import android.content.Context

/**
 * Thin wrapper around SharedPreferences for the three credentials Jarvis needs.
 * Free tiers this is built against:
 *   - Groq  (console.groq.com)  -> LLM used to turn loose/slang speech into a structured command
 *   - Fish Audio (fish.audio)   -> text-to-speech for Jarvis's spoken replies
 */
class AppSettings(context: Context) {

    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    var groqApiKey: String
        get() = prefs.getString(KEY_GROQ, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GROQ, value).apply()

    var fishApiKey: String
        get() = prefs.getString(KEY_FISH_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FISH_KEY, value).apply()

    var fishVoiceId: String
        get() = prefs.getString(KEY_FISH_VOICE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FISH_VOICE, value).apply()

    fun isConfigured(): Boolean =
        groqApiKey.isNotBlank() && fishApiKey.isNotBlank() && fishVoiceId.isNotBlank()

    companion object {
        private const val KEY_GROQ = "groq_api_key"
        private const val KEY_FISH_KEY = "fish_api_key"
        private const val KEY_FISH_VOICE = "fish_voice_id"
    }
}
