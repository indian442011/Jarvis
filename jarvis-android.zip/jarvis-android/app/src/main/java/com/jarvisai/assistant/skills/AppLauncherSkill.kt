package com.jarvisai.assistant.skills

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import com.jarvisai.assistant.JarvisCommand

/**
 * Fallback skill: opens ANY installed app by matching its label, using Android's normal
 * launch-intent mechanism (no accessibility tricks needed just to open something).
 * This is what handles "open camera", "take me to YouTube", "open my phone [settings]", etc.
 * when there's no dedicated Skill with deeper in-app behaviour for that app.
 */
class AppLauncherSkill : Skill {

    override val appPackageName: String = "*"

    override fun canHandle(command: JarvisCommand): Boolean =
        command.action == "open" || command.action == "search"

    override fun execute(service: AccessibilityService, command: JarvisCommand): SkillResult {
        val pm = service.packageManager
        val wanted = command.app.lowercase()

        val match = pm.getInstalledApplications(0).firstOrNull { appInfo ->
            pm.getApplicationLabel(appInfo).toString().lowercase().contains(wanted)
        } ?: return SkillResult.Failed("No installed app matches \"${command.app}\".")

        val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            ?: return SkillResult.Failed("\"${command.app}\" has no launchable activity.")

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        service.startActivity(launchIntent)
        return SkillResult.Success("Opened ${pm.getApplicationLabel(match)}.")
    }
}
