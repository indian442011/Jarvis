package com.jarvisai.assistant.skills

import android.accessibilityservice.AccessibilityService
import com.jarvisai.assistant.JarvisCommand

/** Result of trying to carry out a command inside an app. */
sealed class SkillResult {
    data class Success(val confirmation: String, val screenshotPath: String? = null) : SkillResult()
    data class Failed(val reason: String) : SkillResult()
}

/**
 * One Skill = one app Jarvis knows how to drive via the Accessibility Service.
 * `canHandle` decides routing; `execute` does the actual find-node/click/type work.
 * Add a new file in this package + register it in SkillRegistry to support another app.
 */
interface Skill {
    val appPackageName: String
    fun canHandle(command: JarvisCommand): Boolean
    fun execute(service: AccessibilityService, command: JarvisCommand): SkillResult
}
