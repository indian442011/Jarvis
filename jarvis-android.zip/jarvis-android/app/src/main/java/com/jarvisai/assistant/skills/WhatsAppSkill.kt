package com.jarvisai.assistant.skills

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import com.jarvisai.assistant.JarvisCommand

/**
 * Example "act inside an app" skill: finds a contact by name in WhatsApp's chat list,
 * opens the chat, types the message, and taps send — all via Accessibility node lookups,
 * since there's no public WhatsApp API for this.
 *
 * NOTE: WhatsApp's UI (view IDs, layout) changes between versions/updates, so the text-based
 * matching in UiHelper is intentionally used instead of hardcoded view IDs, but you should
 * expect to tweak the search terms here ("Search", "Send") if WhatsApp updates its labels.
 */
class WhatsAppSkill : Skill {

    override val appPackageName: String = "com.whatsapp"

    override fun canHandle(command: JarvisCommand): Boolean =
        command.app == "whatsapp" && command.action == "send_message"

    override fun execute(service: AccessibilityService, command: JarvisCommand): SkillResult {
        val contact = command.target ?: return SkillResult.Failed("No recipient given.")
        val message = command.text ?: return SkillResult.Failed("No message text given.")

        val pm = service.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(appPackageName)
            ?: return SkillResult.Failed("WhatsApp isn't installed.")
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        service.startActivity(launchIntent)

        // 1. Wait for WhatsApp's chat list, open the search field
        val searchIcon = UiHelper.waitFor { UiHelper.findNodeContaining(UiHelper.rootNode(service), "Search") }
            ?: return SkillResult.Failed("Couldn't find WhatsApp's search button.")
        UiHelper.click(searchIcon)

        // 2. Type the contact name and wait for a matching result
        val searchField = UiHelper.waitFor { UiHelper.findFirstEditableField(UiHelper.rootNode(service)) }
            ?: return SkillResult.Failed("Couldn't find the search field.")
        UiHelper.setText(searchField, contact)

        val contactResult = UiHelper.waitFor { UiHelper.findNodeContaining(UiHelper.rootNode(service), contact) }
            ?: return SkillResult.Failed("No contact matching \"$contact\" found.")
        UiHelper.click(contactResult)

        // 3. Type the message into the chat's compose box and send it
        val composeBox = UiHelper.waitFor { UiHelper.findFirstEditableField(UiHelper.rootNode(service)) }
            ?: return SkillResult.Failed("Couldn't find the message box.")
        UiHelper.setText(composeBox, message)

        val sendButton = UiHelper.waitFor { UiHelper.findNodeContaining(UiHelper.rootNode(service), "Send") }
            ?: return SkillResult.Failed("Couldn't find the send button.")
        UiHelper.click(sendButton)

        return SkillResult.Success("Sent \"$message\" to $contact on WhatsApp.")
    }
}
