package com.jarvisai.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Wraps Fish Audio's TTS endpoint (https://api.fish.audio/v1/tts) so Jarvis can speak
 * its replies back in the configured voice. Uses the "s2" model, Fish Audio's
 * standard-tier synthesis model.
 */
class FishAudioClient(private val apiKey: String, private val voiceReferenceId: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /** Synthesizes [text] and writes the resulting mp3 to [outFile]. */
    fun synthesizeToFile(text: String, outFile: File): Result<File> = try {
        val body = JSONObject().apply {
            put("text", text)
            put("reference_id", voiceReferenceId)
            put("format", "mp3")
        }

        val request = Request.Builder()
            .url("https://api.fish.audio/v1/tts")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .addHeader("model", "s2")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) {
                return Result.failure(Exception("Fish Audio error ${resp.code}: ${resp.body?.string()}"))
            }
            outFile.outputStream().use { out ->
                resp.body?.byteStream()?.copyTo(out)
            }
            Result.success(outFile)
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}
