package com.jarvisai.assistant.skills

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import com.jarvisai.assistant.JarvisCommand

/** Example skill: open YouTube and, if a search target was given, search for it. */
class YouTubeSkill : Skill {

    override val appPackageName: String = "com.google.android.youtube"

    override fun canHandle(command: JarvisCommand): Boolean =
        command.app == "youtube" && (command.action == "open" || command.action == "search")

    override fun execute(service: AccessibilityService, command: JarvisCommand): SkillResult {
        val pm = service.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(appPackageName)
            ?: return SkillResult.Failed("YouTube isn't installed.")
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        service.startActivity(launchIntent)

        val query = command.target ?: command.text
        if (command.action == "open" || query.isNullOrBlank()) {
            return SkillResult.Success("Opened YouTube.")
        }

        val searchIcon = UiHelper.waitFor { UiHelper.findNodeContaining(UiHelper.rootNode(service), "Search") }
            ?: return SkillResult.Failed("Couldn't find YouTube's search button.")
        UiHelper.click(searchIcon)

        val searchField = UiHelper.waitFor { UiHelper.findFirstEditableField(UiHelper.rootNode(service)) }
            ?: return SkillResult.Failed("Couldn't find the search field.")
        UiHelper.setText(searchField, query)

        return SkillResult.Success("Searched YouTube for \"$query\".")
    }
}
