package com.jarvisai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.jarvisai.assistant.databinding.ActivityMainBinding
import com.jarvisai.assistant.skills.SkillResult
import java.io.File

/**
 * v0.1 scope: tap-to-speak, one command at a time. An always-listening wake word
 * ("hey Jarvis") is a natural next step (see README) but needs its own on-device
 * wake-word engine — bolting that on top of this flow is straightforward once this
 * loop (speech -> Groq -> skill -> Fish Audio reply) is working end-to-end.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: AppSettings
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = AppSettings(this)
        binding.inputGroqKey.setText(settings.groqApiKey)
        binding.inputFishKey.setText(settings.fishApiKey)
        binding.inputFishVoiceId.setText(settings.fishVoiceId)

        binding.btnSave.setOnClickListener {
            settings.groqApiKey = binding.inputGroqKey.text.toString().trim()
            settings.fishApiKey = binding.inputFishKey.text.toString().trim()
            settings.fishVoiceId = binding.inputFishVoiceId.text.toString().trim()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }

        binding.btnEnableAccessibility.setOnClickListener {
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnMic.setOnClickListener { onMicTapped() }
    }

    private fun onMicTapped() {
        if (!settings.isConfigured()) {
            setStatus("Add your Groq + Fish Audio keys above and tap Save first.")
            return
        }
        if (!JarvisAccessibilityService.isReady()) {
            setStatus("Turn on the Accessibility Service first (button 1 above).")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
            return
        }
        startListening()
    }

    private fun startListening() {
        setStatus("Listening...")
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    val heard = results
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (heard.isNullOrBlank()) {
                        setStatus("Didn't catch that.")
                    } else {
                        appendLog("Heard: \"$heard\"")
                        handleHeardText(heard)
                    }
                }

                override fun onError(error: Int) {
                    setStatus("Speech error code $error")
                }

                override fun onReadyForSpeech(params: Bundle?) {
                    setStatus("Listening...")
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    setStatus("Thinking...")
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                }
            )
        }
    }

    private fun handleHeardText(heard: String) {
        setStatus("Thinking...")
        Thread {
            val groq = GroqClient(settings.groqApiKey)
            groq.parseCommand(heard).fold(
                onSuccess = { command -> runOnUiThread { executeCommand(command) } },
                onFailure = { err -> runOnUiThread { setStatus("Groq error: ${err.message}") } }
            )
        }.start()
    }

    private fun executeCommand(command: JarvisCommand) {
        appendLog("Command: ${command.app}/${command.action} target=${command.target} text=${command.text}")
        setStatus("Doing it...")
        speak(command.reply)

        JarvisAccessibilityService.runCommand(command) { result ->
            when (result) {
                is SkillResult.Success -> {
                    setStatus("Done.")
                    appendLog("\u2705 ${result.confirmation}")
                }
                is SkillResult.Failed -> {
                    setStatus("Failed.")
                    appendLog("\u274C ${result.reason}")
                }
            }
        }
    }

    private fun speak(text: String) {
        if (settings.fishApiKey.isBlank() || settings.fishVoiceId.isBlank()) return
        Thread {
            val fish = FishAudioClient(settings.fishApiKey, settings.fishVoiceId)
            val outFile = File(cacheDir, "jarvis_reply.mp3")
            fish.synthesizeToFile(text, outFile).onSuccess { file ->
                runOnUiThread {
                    MediaPlayer().apply {
                        setDataSource(file.absolutePath)
                        setOnPreparedListener { it.start() }
                        setOnCompletionListener { it.release() }
                        prepareAsync()
                    }
                }
            }
        }.start()
    }

    private fun setStatus(text: String) {
        binding.txtStatus.text = "Status: $text"
    }

    private fun appendLog(line: String) {
        binding.txtLog.text = "${binding.txtLog.text}\n$line"
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer?.destroy()
    }
}
