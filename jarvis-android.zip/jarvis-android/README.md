# Jarvis (Android)

A voice assistant that listens for a loose/slang spoken command, turns it into a structured
action using Groq's free LLM tier, and carries it out by driving the screen (via Android's
Accessibility API) or launching apps — then speaks a confirmation back using Fish Audio TTS.

## What it can actually do (v0.1)

- Tap the mic button, say something like **"take me to YouTube"** or **"send hi to mom on
  whatsapp"** → Groq turns that into `{app, action, target, text}` → the matching **Skill**
  carries it out by launching the app and, for WhatsApp, finding the contact/search/compose/send
  controls on screen and driving them.
- Speaks its reply out loud using your Fish Audio voice.
- Shows a text log of exactly what it did (which skill ran, and whether it succeeded).

## What it deliberately does NOT do, and why

- **It cannot unlock your phone.** Android does not let any third-party app bypass the lock
  screen — this is a core OS security boundary, not a missing feature. The only "voice unlock"
  that exists is Google's own on-device Voice Match, which isn't exposed to other apps. If the
  phone is locked, the Accessibility Service has literally no screen content to read.
- **It cannot act while the screen is off/locked** for the same reason — commands only work once
  you've unlocked the phone yourself.
- It has no special "full access" — it only has whatever you explicitly grant (mic, and the
  Accessibility Service toggle you turn on by hand in Settings). That's an Android platform limit,
  not a design choice made here.

## Setup

1. **Get free API keys** (both have no-cost tiers):
   - Groq: sign up at console.groq.com → create an API key.
   - Fish Audio: sign up at fish.audio → create an API key, and grab a **voice/reference ID**
     from any voice on the site (visible in its URL, or via "copy ID" on the voice page).
2. Open this folder in **Android Studio** (Hedgehog or newer). Studio will auto-generate the
   Gradle wrapper (`gradlew`/`gradle-wrapper.jar`) the first time you open/sync — commit those
   two generated files so the GitHub Actions workflow below can build headlessly.
3. Run it on your phone (USB debugging, or build the APK — see below).
4. In the app: paste your Groq key, Fish Audio key, and Fish Audio voice ID → **Save settings**.
5. Tap **"1. Turn on Accessibility Service"** → find "Jarvis" in the list → enable it. Android
   will show a warning dialog about the permission's scope; that's expected for any app that
   drives the screen (Tasker, Automate, etc. show the same one).
6. Tap the mic button and speak a command.

## Getting an APK from GitHub

`.github/workflows/build-apk.yml` builds a debug APK on every push to `main` and uploads it as a
downloadable build artifact (Actions tab → latest run → Artifacts). If you'd rather have it
attached to a GitHub **Release** automatically, add a `release.yml` trigger on tag push and swap
the `upload-artifact` step for `softprops/action-gh-release`.

## Adding a new app ("skill")

1. Create `app/src/main/java/com/jarvisai/assistant/skills/YourAppSkill.kt` implementing `Skill`.
2. Use `UiHelper.findNodeContaining(...)`, `.click(...)`, `.setText(...)` to drive its screen —
   the same pattern as `WhatsAppSkill.kt`.
3. Register it in `SkillRegistry.kt` (above `AppLauncherSkill()`, which is the generic fallback).
4. Update the Groq system prompt in `GroqClient.kt` if the app needs a new `action` type.

## Known rough edges to expect

- Text-based node matching (searching for "Send", "Search", etc.) breaks when an app updates its
  UI labels or ships a redesign — this is the same fragility every Accessibility-based automation
  tool (Tasker, Automate, Macrodroid) has; there's no public API alternative for "control any app."
- No always-listening wake word yet — it's tap-to-speak. Adding "hey Jarvis" needs an on-device
  wake-word engine (e.g. Porcupine's free tier) running in a foreground service that then hands
  off to the same `SpeechRecognizer` → Groq → Skill pipeline already built here.
- No real screenshot capture yet — `SkillResult.confirmation` is a text description of what
  happened. A literal screenshot needs the `MediaProjection` API, which requires a one-tap user
  permission grant each session (also an Android security boundary, not a bug here).
